#!/usr/bin/env bash
#
# setup_dxvk.sh - Install/uninstall DXVK DLLs into a Wine prefix (32-bit + 64-bit)
#
# Expected layout:
#   .
#   ├── setup_dxvk.sh
#   ├── x32/
#   │   ├── d3d10core.dll
#   │   ├── d3d11.dll
#   │   ├── d3d8.dll
#   │   ├── d3d9.dll
#   │   └── dxgi.dll
#   └── x64/
#       ├── d3d10core.dll
#       ├── d3d11.dll
#       ├── d3d8.dll
#       ├── d3d9.dll
#       └── dxgi.dll
#
# Usage:
#   WINEPREFIX=/path/to/prefix ./setup_dxvk.sh install [--symlink]
#   WINEPREFIX=/path/to/prefix ./setup_dxvk.sh uninstall
#
set -euo pipefail

# default directories
dxvk_lib32=${dxvk_lib32:-"x32"}
dxvk_lib64=${dxvk_lib64:-"x64"}

# figure out where we are
basedir=$(dirname "$(readlink -f "$0")")

# figure out which action to perform
action="${1:-}"

case "$action" in
install) ;;
uninstall) ;;
*)
  echo "Unrecognized action: ${action:-}"
  echo "Usage: $0 [install|uninstall] [--symlink]"
  exit 1
  ;;
esac

# process arguments
shift || true

file_cmd="cp -v"
while (($# > 0)); do
  case "$1" in
  "--symlink")
    file_cmd="ln -s -v"
    ;;
  esac
  shift
done

# check wine prefix before invoking wine, so that we
# don't accidentally create one if the user screws up
if [ -n "${WINEPREFIX:-}" ] && ! [ -f "$WINEPREFIX/system.reg" ]; then
  echo "$WINEPREFIX:"' Not a valid wine prefix.' >&2
  exit 1
fi

# find wine executables
export WINEDEBUG=-all
# disable mscoree and mshtml to avoid downloading wine gecko/mono
export WINEDLLOVERRIDES="mscoree,mshtml="

wineboot="wineboot"
wine="wine"
wine64="wine64"

wine_path="$(dirname "$(command -v "$wineboot")")"

# If wine64 isn't present, fall back to wine (some builds ship only wine/wineboot)
if ! command -v "$wine64" >/dev/null 2>&1; then
  wine64="$wine"
fi

# Detect pure-64-bit (non-WoW64) installs: missing "wine" next to wineboot
wow64=true
if ! [ -f "$wine_path/$wine" ]; then
  wine="$wine64"
  wow64=false
fi

# sanity check
if ! "$wine" --version | grep -qi wine; then
  echo "$wine: Not a wine executable. Check PATH." >&2
  exit 1
fi

# ensure wine placeholder dlls are recreated if they are missing
"$wineboot" -u

# resolve 64-bit system32 path
win64_sys_path="$("$wine64" winepath -u 'C:\windows\system32' 2>/dev/null || true)"
win64_sys_path="${win64_sys_path/$'\r'/}"

# resolve 32-bit system path (prefer syswow64 explicitly when WoW64)
win32_sys_path=""
if $wow64; then
  win32_sys_path="$("$wine" winepath -u 'C:\windows\syswow64' 2>/dev/null || true)"
  win32_sys_path="${win32_sys_path/$'\r'/}"

  # fallback (some setups still map 32-bit via system32 from 32-bit wine)
  if [ -z "$win32_sys_path" ]; then
    win32_sys_path="$("$wine" winepath -u 'C:\windows\system32' 2>/dev/null || true)"
    win32_sys_path="${win32_sys_path/$'\r'/}"
  fi
fi

if [ -z "$win64_sys_path" ] && [ -z "$win32_sys_path" ]; then
  echo "Failed to resolve Wine system directories." >&2
  exit 1
fi

echo "[dxvk] win64_sys_path=$win64_sys_path"
echo "[dxvk] win32_sys_path=$win32_sys_path (wow64=$wow64)"

# copy or link dll, back up original file
installFile() {
  # $1 = dst dir, $2 = src subdir, $3 = dll base name (no .dll)
  dstfile="${1}/${3}.dll"
  srcfile="${basedir}/${2}/${3}.dll"

  if ! [ -f "${srcfile}" ]; then
    echo "${srcfile}: File not found. Skipping." >&2
    return 1
  fi

  if [ -n "$1" ]; then
    if [ -f "${dstfile}" ] || [ -h "${dstfile}" ]; then
      if ! [ -f "${dstfile}.old" ]; then
        mv -v "${dstfile}" "${dstfile}.old"
      else
        rm -v "${dstfile}"
      fi
    else
      touch "${dstfile}.old_none"
    fi
    $file_cmd "${srcfile}" "${dstfile}"
  fi
  return 0
}

# remove dll, restore original file
uninstallFile() {
  dstfile="${1}/${3}.dll"
  srcfile="${basedir}/${2}/${3}.dll"

  if ! [ -f "${srcfile}" ]; then
    echo "${srcfile}: File not found. Skipping." >&2
    return 1
  fi

  if ! [ -f "${dstfile}" ] && ! [ -h "${dstfile}" ]; then
    echo "${dstfile}: File not found. Skipping." >&2
    return 1
  fi

  if [ -f "${dstfile}.old" ]; then
    rm -v "${dstfile}"
    mv -v "${dstfile}.old" "${dstfile}"
    return 0
  elif [ -f "${dstfile}.old_none" ]; then
    rm -v "${dstfile}.old_none"
    rm -v "${dstfile}"
    return 0
  else
    return 1
  fi
}

install_one() {
  local dll="$1"

  if [ -n "$win64_sys_path" ]; then
    installFile "$win64_sys_path" "$dxvk_lib64" "$dll"
  fi

  if $wow64 && [ -n "$win32_sys_path" ]; then
    installFile "$win32_sys_path" "$dxvk_lib32" "$dll"
  fi
}

uninstall_one() {
  local dll="$1"

  if [ -n "$win64_sys_path" ]; then
    uninstallFile "$win64_sys_path" "$dxvk_lib64" "$dll"
  fi

  if $wow64 && [ -n "$win32_sys_path" ]; then
    uninstallFile "$win32_sys_path" "$dxvk_lib32" "$dll"
  fi
}

DXVK_DLLS=(
  d3d8
  d3d9
  d3d10core
  d3d11
  dxgi
)

for dll in "${DXVK_DLLS[@]}"; do
  "${action}_one" "$dll"
done

